(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 2321:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _image;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgMyicon = function SvgMyicon(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 32,
    height: 32
  }, props), _image || (_image = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("image", {
    "data-name": "STUDY ABROAD",
    width: 32,
    height: 38,
    xlinkHref: "data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAmCAYAAAClI5npAAAIJElEQVRYhbWYCYxdVRnHf9859y0zb9YO02k7UwwFQQURsQFKWVosbQNCDTuSgAIpuxqXIAjKIomSiBEEBSJE1AAWglaEoNFSRpqC2iIlpYUOIdgp0nams3TmLffe85lz35vOzOsbWiB+k5e5975zv///W893noSrgHrQCMQC/qOUxV8Xgd0gGdA0iCl/JUAc8hOX4S+pQ3jGtJSfL7vscFau/hzTu4bLigScExCXvCUiqCqof6ZU1H1AEYgd345Dvq6D/J6Y6R9KD3wIAt6imIvikDslSJ6kojdZQ0Q2uUk58Bb/PwiIgMYsiEN+MwYhWYgHOZjNvAFkiiUDVvehaVyC/UcHdRwexawau/fiw2mbk3xZv+LOjuJz3V20zBjdb7X75QHRJJ+6YscaKp4oo5eTMt3GY6teaF923kOfX0wud182Fe43gX17QBNrGyJhrSpNUvVVtp3nN7zcdOEpP1vUSj3PtrWpiUPpE7h5fwjs2wMCUZpuNXROAhfINPN6z6sNC0+5e9EcsBtmtO42cZjE/ybQqz4aASmb6JRn1XKUTMgrD5429Inj+OtWHM3O7a3nz2gf6ozjcXUK9wFnfiQCrsRDLmJpteUokYmYR8RA6JMgW7ozjsyj1SoU/gAc+8EJ+IwvcYcL+YpUr1BIh5xMijd95Yfe6kBjhS+BvrwXCaVb4ND9J2DARXzDhdwoVf3EWx84TjeWNb733fXkoazePJPWtlFfDceAdNbASCG6Fjhg3wRMsidcoCV+nORAFQGBy63hGbrg8adn881fH099rkTKuE+hvATUIuClVZC1tapunECly7kSj04BfouFX0oXrO5u54J7F5JqGaWprnSAOl6cAniiHCzw/NQElMNcyN8qdT8Z3HG/ibk1mA0bX2tk0V2LIBvS1lQI4jixrKUG4L+A/qpn84EnJhGoxLnD+S4nyV+15StNxJVBJ/S+leXEO5YQRQEz2kaInVntLasBvsUhc1FO3esb1bNFuXsMx6jjsDjmZZRpk9aVW/ALJmRZMB1277CccMti+vtzzOgY9OB/Ao6vAd7nHMdq0jd0nQgXlieKSVZdJ3Cbvwyc5Tsac2B1xgu8aJST/Ubzznt1LP3RAt5+t4WOzoFc7IxvMqfVAI9Q5inab7wz1SCxPqaGs4FzqlzhW7UYAm4UeL2GsowvcT8Jbe/L8PqWmdhcCSOJ1RfXWI8xugDRN30cAw0wzvod1AMvmehbEYMEqSQBDcq7Unbl9ip9c4ENpT6Y+5kBnrz+OeLhLAND2W5r9MFqcBE5V6RcDZYgSSZn3Eka6AqgcXyh8UyJdg/epsrNY1UwIJqQiKv0HuGEv0Z9cNZpvdxzeTf5HY2FkWJqubW6cjxc8jUj8oSf9ZxqGRx3qBq3alJJCdi6BvLb3nowv7Xn+yaVmdSIelBO2NsyToliHnXb4Nrzerj1ojUMv9dEITLLjPCKqj4icLfXXopjYpcMD53ORC+BTtCv2LpGitu3PjWyZcNyHwLviepWvFZrJJcIF5SK3MMO+N5lG7n69FcY2NpKCJ8VwyVeeajOD6qIaMaZaE25N4yNTWDrU5T6t3UPb1p3lhiLSaWTjaLWZvQscNleJAzX5vNczwDce806vnjiJvp7W5JW5lPff6wIVszfgQPHDRdsvRIN65ahjZsX+tUmky3PclPthgoPUWOiMZYf5of5LgV46ltrOP/EzUlfiJOoewL2aSN27kRwU1fEFbP9g6/NOk5DiU022AM+JYHKuz9AeGDSM5/Ajo/pf4A0HNW5izgMkqZlkfuNyOk6dqrx4JlSMqIPbpgzPx7N9dm6ePzQsy8CFU9cATy5JwzKA2lhubTDz397CDesPI6GtmFScLtVlu/R7cHTYfLCwIZDTi4NNG4K6vOVaeYDEKA8UJyj5QpZH8AVMhMeWz2bq59YQCpXoN66rwrcNBFcUlHyGdo458zi9mkvBLnC3jtcRYJ0Q6Xxj2mQ8f9hHqI4ufy0dUS2C55b3cGFjyzCNOVprSucq5H8lIngNsZmSgxtPOiqfG/7H4PGPOpHp6QiNbEoORomy4Vg104ziYD3kvMuNMq0mY7UKJSGyfuteP2/m1l6zxLIRhzQMDqfkN9NMkcc1kbs3jL79pG3Z/3C5gpEcR0iKYwxe1yqLhl2Ud+S5x1zxMSYJ+Ic9A8HXLJ4Bzdd04sfv7auz3HELWcwOFJHe9vAqZTcn6vdalMh+dGGhwf/8clLibPJ/DOtbSPTW3rKgLoLpJyISRfM1BH07kzvFRcRpRQa7loxi1ffyHLc/Dy/evVoBoeaaZu+o4mSuwGVdxDfFcosbKym0OzWDZqmSwmbaWjuYUbHazQ39GJNidil/fmmvDyZviJcYRA58sgjayaH91gcw7adKYp5Id2eRduaGLW5TDqjJqU2nygSTY5uNhb6W4rYEUvXpgItbT2kMiMUis04tUmfqCVTEpgkCikt4TAMZFqJgjR1UZFiKpskUjoqEJs0EhdpDHeRDUYpxjniOI0kP0xMLe93NhwrUYfQEUq60eC2TCv2QyHJ2q5cwWxNQob6abjXqMyJTBCM0vyGKM0ibrCiowkYqgViOzo6piLwBWAx8ArwCPCOInOd2Iudsf3OBPersaLGznfGftkZOys29gwVaRD4RMW4K4F5wE7gv+9nZS3xzA6q/FLk4+TX1gMfryj2020dsBD8xkhrZUB9t3Ic89PyucCCihE15f1C0OfdWqlOf+jwE9NJFVD/k8RmYBbwOHA4cBTwT8C73Vvs33u4cl9bgP8BpXI37V7OlTcAAAAASUVORK5CYII="
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgMyicon);

/***/ }),

/***/ 1094:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Open_Sans_6e545a', '__Open_Sans_Fallback_6e545a'","fontStyle":"normal"},
	"className": "__className_6e545a",
	"variable": "__variable_6e545a"
};


/***/ }),

/***/ 3847:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _next_font_google_target_css_path_pages_app_tsx_import_Open_Sans_arguments_subsets_latin_weight_400_600_variable_font_osans_variableName_OpenSans___WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1094);
/* harmony import */ var _next_font_google_target_css_path_pages_app_tsx_import_Open_Sans_arguments_subsets_latin_weight_400_600_variable_font_osans_variableName_OpenSans___WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_next_font_google_target_css_path_pages_app_tsx_import_Open_Sans_arguments_subsets_latin_weight_400_600_variable_font_osans_variableName_OpenSans___WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var normalize_css_normalize_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(119);
/* harmony import */ var normalize_css_normalize_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(normalize_css_normalize_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_globals_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3716);
/* harmony import */ var _styles_globals_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_scss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks_useMediaQuery__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(936);
/* harmony import */ var _scenes_Navbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6093);
/* harmony import */ var _scenes_Footer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7325);
/* harmony import */ var _components_AppContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1799);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_scenes_Navbar__WEBPACK_IMPORTED_MODULE_5__]);
_scenes_Navbar__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









// className={`${OpenSans.variable} font-playfair`}
function App({ Component , pageProps  }) {
    const [selectedPage, setSelectedPage] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("home");
    const isAboveMediumScreen = (0,_hooks_useMediaQuery__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)("(min-width: 1060px)");
    //  const isAboveMediumScreen = useMediaQuery("(min-width: 800px)");
    const [isTopOfPage, setIsTopOfPage] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(true);
    const [isinHomePage, setisinHomePage] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        const handleScroll = ()=>{
            if (window.scrollY === 0) {
                setIsTopOfPage(true);
                setSelectedPage("home");
            }
            if (window.scrollY !== 0) setIsTopOfPage(false);
        };
        window.addEventListener("scroll", handleScroll);
        return ()=>window.removeEventListener("scroll", handleScroll);
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
        className: `${(_next_font_google_target_css_path_pages_app_tsx_import_Open_Sans_arguments_subsets_latin_weight_400_600_variable_font_osans_variableName_OpenSans___WEBPACK_IMPORTED_MODULE_8___default().variable)} font-opensans bg-deep-blue`,
        children: [
            " ",
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_AppContext__WEBPACK_IMPORTED_MODULE_7__/* ["default"].Provider */ .Z.Provider, {
                value: {
                    selectedPage,
                    isAboveMediumScreen,
                    setSelectedPage,
                    isinHomePage,
                    setisinHomePage
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_scenes_Navbar__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        isTopOfPage: isTopOfPage,
                        selectedPage: selectedPage,
                        setSelectedPage: setSelectedPage,
                        isinHomePage: isinHomePage,
                        setisinHomePage: setisinHomePage
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                        ...pageProps
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_scenes_Footer__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7325:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ scenes_Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-anchor-link-smooth-scroll"
var external_react_anchor_link_smooth_scroll_ = __webpack_require__(2217);
var external_react_anchor_link_smooth_scroll_default = /*#__PURE__*/__webpack_require__.n(external_react_anchor_link_smooth_scroll_);
// EXTERNAL MODULE: ./hooks/useMediaQuery.tsx
var useMediaQuery = __webpack_require__(936);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./scenes/navCategories/navbg3.tsx






const LinkC = ({ page , selectedPage , setSelectedPage  })=>{
    const lowerCasePage = page.toLowerCase();
    return /*#__PURE__*/ jsx_runtime_.jsx((external_react_anchor_link_smooth_scroll_default()), {
        className: `${selectedPage === lowerCasePage ? "text-yellow" : ""} hover:text-yellow transition duration-500`,
        href: `#${lowerCasePage}`,
        onClick: ()=>setSelectedPage(lowerCasePage),
        children: page
    });
};
function Navbg3({ isTopOfPage , selectedPage , setSelectedPage , isinHomePage , setisinHomePage  }) {
    const [isMenuToggled, setIsMenuToggled] = (0,external_react_.useState)(false);
    const isAboveMediumScreen = (0,useMediaQuery/* default */.Z)("(min-width: 890px)");
    var navbarBackground = isTopOfPage ? "" : "bg-red";
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: isinHomePage ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: " grid justify-between justify-items-center font-opensans text-lg font-semibold",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(LinkC, {
                    page: "Home",
                    className: "w-1/3",
                    selectedPage: selectedPage,
                    setSelectedPage: setSelectedPage
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(LinkC, {
                    page: "Contact",
                    className: "w-1/3",
                    selectedPage: selectedPage,
                    setSelectedPage: setSelectedPage
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(LinkC, {
                    page: "Services",
                    className: "w-1/3",
                    selectedPage: selectedPage,
                    setSelectedPage: setSelectedPage
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/aboutUs",
                    className: "w-1/3",
                    legacyBehavior: true,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: " hover:text-yellow transition duration-500",
                        children: "About Us"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(LinkC, {
                    page: "Testimonials",
                    className: "w-1/3",
                    selectedPage: selectedPage,
                    setSelectedPage: setSelectedPage
                })
            ]
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: " grid justify-items-center font-opensans text-lg font-semibold",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    legacyBehavior: true,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: " hover:text-yellow transition duration-500",
                        children: "Home"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/#contact",
                    legacyBehavior: true,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: " hover:text-yellow transition duration-500",
                        children: "Contact"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/#services",
                    legacyBehavior: true,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: " hover:text-yellow transition duration-500",
                        children: "Services"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/aboutUs",
                    className: "w-1/3",
                    legacyBehavior: true,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: " hover:text-yellow transition duration-500",
                        children: "About Us"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/#testimonials",
                    legacyBehavior: true,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: " hover:text-yellow transition duration-500",
                        children: "Testimonials"
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const navbg3 = (Navbg3);

// EXTERNAL MODULE: ./components/LineGradient.tsx
var LineGradient = __webpack_require__(3417);
;// CONCATENATED MODULE: ./scenes/navCategories/navbg4.tsx





const navbg4_LinkC = ({ page , selectedPage , setSelectedPage  })=>{
    const lowerCasePage = page.toLowerCase();
    return /*#__PURE__*/ _jsx(AnchorLink, {
        className: `${selectedPage === lowerCasePage ? "text-yellow" : ""} hover:text-yellow transition duration-500`,
        href: `#${lowerCasePage}`,
        onClick: ()=>setSelectedPage(lowerCasePage),
        children: page
    });
};
function Navbg4({ isTopOfPage , selectedPage , setSelectedPage , isinHomePage , setisinHomePage  }) {
    const [isMenuToggled, setIsMenuToggled] = (0,external_react_.useState)(false);
    const isAboveMediumScreen = (0,useMediaQuery/* default */.Z)("(min-width: 890px)");
    var navbarBackground = isTopOfPage ? "" : "bg-red";
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: " grid justify-items-center font-opensans text-sm ",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "7th Floor"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "National Pearl Star Building"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "Palarivattam, Edappally Road"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "Kochi, Kerala, 682024"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "Mobile 1 - 9207400080 "
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "Mobile 2 - 7034277964 "
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "Email - admin@leadsflyedu.com"
                })
            ]
        })
    });
}
/* harmony default export */ const navbg4 = (Navbg4);

;// CONCATENATED MODULE: ./scenes/navCategories/navbg5.tsx





const navbg5_LinkC = ({ page , selectedPage , setSelectedPage  })=>{
    const lowerCasePage = page.toLowerCase();
    return /*#__PURE__*/ _jsx(AnchorLink, {
        className: `${selectedPage === lowerCasePage ? "text-yellow" : ""} hover:text-yellow transition duration-500`,
        href: `#${lowerCasePage}`,
        onClick: ()=>setSelectedPage(lowerCasePage),
        children: page
    });
};
function Navbg5({ isTopOfPage , selectedPage , setSelectedPage , isinHomePage , setisinHomePage  }) {
    const [isMenuToggled, setIsMenuToggled] = (0,external_react_.useState)(false);
    const isAboveMediumScreen = (0,useMediaQuery/* default */.Z)("(min-width: 890px)");
    var navbarBackground = isTopOfPage ? "" : "bg-red";
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: " grid justify-items-center font-opensans text-sm ",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "VP Mall"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "Melakkam, Ooty Road"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "Manjeri Malappuram"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: " Kerala, 676121"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "Mobile 1 - 9207400080 "
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "Mobile 2 - 7034277964 "
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "Email - admin@leadsflyedu.com"
                })
            ]
        })
    });
}
/* harmony default export */ const navbg5 = (Navbg5);

;// CONCATENATED MODULE: ./scenes/Footer.tsx






function Footer() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: "flex flex-wrap footer-distributed bg-red pt-3 ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-full flex justify-center justify-items-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: " w-full text-center ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: "mb-2",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Leadsfly"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: "text-white font-light leading-5 mb-5 ",
                            children: [
                                " ",
                                "Leading path to a global future",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {
                                    className: "hidden xs:block "
                                }),
                                "Enable your future possibilities and create enduring tales"
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-5",
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(LineGradient/* default */.Z, {})
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: " w-full ssf:w-4/12 flex justify-center justify-items-center content-center items-start ",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "w-full",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: " mb-3 mt-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-center text-2xl text-fcolor",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "Office Kochi"
                                    })
                                }),
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(navbg4, {})
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(LineGradient/* default */.Z, {})
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: " w-full ssf:w-4/12 flex justify-center justify-items-center content-center items-start ",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "w-full",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: " mb-3 mt-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-center text-2xl text-fcolor",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "Office Malappuram"
                                    })
                                }),
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(navbg5, {})
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(LineGradient/* default */.Z, {})
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: " w-full ssf:w-4/12 flex justify-center justify-items-center content-center items-start ",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "w-full",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: " mb-3 mt-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-center text-2xl text-fcolor",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "Navigation"
                                    })
                                }),
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(navbg3, {})
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(LineGradient/* default */.Z, {})
                            ]
                        })
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const scenes_Footer = (Footer);


/***/ }),

/***/ 6093:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Navbar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _navCategories_navbg1__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18);
/* harmony import */ var _navCategories_navbg2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1900);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_navCategories_navbg1__WEBPACK_IMPORTED_MODULE_2__, _navCategories_navbg2__WEBPACK_IMPORTED_MODULE_3__]);
([_navCategories_navbg1__WEBPACK_IMPORTED_MODULE_2__, _navCategories_navbg2__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





function Navbar({ isTopOfPage , selectedPage , setSelectedPage , isinHomePage , setisinHomePage  }) {
    var navbarBackground = isTopOfPage ? "bg-white" : "bg-yellow";
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: isinHomePage ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_navCategories_navbg1__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            isTopOfPage: isTopOfPage,
            selectedPage: selectedPage,
            setSelectedPage: setSelectedPage,
            isinHomePage: isinHomePage,
            setisinHomePage: setisinHomePage
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_navCategories_navbg2__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            isTopOfPage: isTopOfPage,
            selectedPage: selectedPage,
            setSelectedPage: setSelectedPage,
            isinHomePage: isinHomePage,
            setisinHomePage: setisinHomePage
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 18:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2217);
/* harmony import */ var react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks_useMediaQuery__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(936);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6197);
/* harmony import */ var _public_assets_myicon_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2321);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_5__]);
framer_motion__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const LinkC = ({ page , selectedPage , setSelectedPage  })=>{
    const lowerCasePage = page.toLowerCase();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_2___default()), {
        className: `${selectedPage === lowerCasePage ? "text-yellow" : ""} hover:text-yellow transition duration-500`,
        href: `#${lowerCasePage}`,
        onClick: ()=>setSelectedPage(lowerCasePage),
        children: page
    });
};
function Navbg1({ isTopOfPage , selectedPage , setSelectedPage , isinHomePage , setisinHomePage  }) {
    const [isMenuToggled, setIsMenuToggled] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const isAboveMediumScreen = (0,_hooks_useMediaQuery__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)("(min-width: 890px)");
    var navbarBackground = isTopOfPage ? "" : "bg-red";
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
        className: `${navbarBackground} z-40 w-full fixed top-0 py-2 sme:py-4 md:py-4 h-16`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex items-center justify-between mx-auto w-5/6",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_public_assets_myicon_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                isAboveMediumScreen ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-between gap-16 font-opensans text-lg font-semibold",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LinkC, {
                            page: "Home",
                            selectedPage: selectedPage,
                            setSelectedPage: setSelectedPage
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LinkC, {
                            page: "Services",
                            selectedPage: selectedPage,
                            setSelectedPage: setSelectedPage
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LinkC, {
                            page: "Testimonials",
                            selectedPage: selectedPage,
                            setSelectedPage: setSelectedPage
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                            href: "/aboutUs",
                            legacyBehavior: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: " hover:text-yellow transition duration-500",
                                children: "About Us"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LinkC, {
                            page: "Contact",
                            selectedPage: selectedPage,
                            setSelectedPage: setSelectedPage
                        })
                    ]
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: "rounded-full bg-red p-2",
                    onClick: ()=>setIsMenuToggled(!isMenuToggled),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                        alt: "menu-icon",
                        src: "/assets/menu-icon.svg",
                        width: 32,
                        height: 32
                    })
                }),
                !isAboveMediumScreen && isMenuToggled && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.AnimatePresence, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                        initial: {
                            x: 350
                        },
                        animate: {
                            x: 0
                        },
                        exit: {
                            x: 350
                        },
                        transition: {
                            duration: 3,
                            type: "spring",
                            stiffness: 120
                        },
                        className: "fixed right-0 bottom-0 h-full bg-blue w-[300px] rounded-l-full border-l-8 ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex justify-end p-12",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: ()=>setIsMenuToggled(!isMenuToggled),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        alt: "close-icon",
                                        src: "/assets/close-icon.svg",
                                        width: 32,
                                        height: 32
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col gap-10 ml-[33%] text-2xl text-deep-blue",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LinkC, {
                                        page: "Home",
                                        selectedPage: selectedPage,
                                        setSelectedPage: setSelectedPage
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LinkC, {
                                        page: "Services",
                                        selectedPage: selectedPage,
                                        setSelectedPage: setSelectedPage
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LinkC, {
                                        page: "Testimonials",
                                        selectedPage: selectedPage,
                                        setSelectedPage: setSelectedPage
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        href: "/aboutUs",
                                        legacyBehavior: true,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: " hover:text-yellow transition duration-500",
                                            children: "About Us"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LinkC, {
                                        page: "Contact",
                                        selectedPage: selectedPage,
                                        setSelectedPage: setSelectedPage
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navbg1);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1900:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2217);
/* harmony import */ var react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_anchor_link_smooth_scroll__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks_useMediaQuery__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(936);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6197);
/* harmony import */ var _public_assets_myicon_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2321);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_5__]);
framer_motion__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const LinkC = ({ page , selectedPage , setSelectedPage  })=>{
    const lowerCasePage = page.toLowerCase();
    return /*#__PURE__*/ _jsx(AnchorLink, {
        className: `${selectedPage === lowerCasePage ? "text-yellow" : ""} hover:text-yellow transition duration-500`,
        href: `#${lowerCasePage}`,
        onClick: ()=>setSelectedPage(lowerCasePage),
        children: page
    });
};
function Navbg2({ isTopOfPage , selectedPage , setSelectedPage , isinHomePage , setisinHomePage  }) {
    const [isMenuToggled, setIsMenuToggled] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const isAboveMediumScreen = (0,_hooks_useMediaQuery__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)("(min-width: 890px)");
    var navbarBackground = isTopOfPage ? "bg-red" : "bg-red";
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
        className: `${navbarBackground} z-40 w-full fixed top-0 py-2 sme:py-4 md:py-4 h-16`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex items-center justify-between mx-auto w-5/6",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_public_assets_myicon_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                isAboveMediumScreen ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-between gap-16 font-opensans text-lg font-semibold",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                            href: "/",
                            legacyBehavior: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: " hover:text-yellow transition duration-500",
                                children: "Home"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                            href: "/#services",
                            legacyBehavior: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: " hover:text-yellow transition duration-500",
                                children: "Services"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                            href: "/#testimonials",
                            legacyBehavior: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: " hover:text-yellow transition duration-500",
                                children: "Testimonials"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                            href: "/aboutUs",
                            legacyBehavior: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: " text-yellow transition duration-500",
                                children: "About Us"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                            href: "/#contact",
                            legacyBehavior: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: " hover:text-yellow transition duration-500",
                                children: "Contact"
                            })
                        })
                    ]
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: "rounded-full bg-red p-2",
                    onClick: ()=>setIsMenuToggled(!isMenuToggled),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                        alt: "menu-icon",
                        src: "/assets/menu-icon.svg",
                        width: 32,
                        height: 32
                    })
                }),
                !isAboveMediumScreen && isMenuToggled && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.AnimatePresence, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                        initial: {
                            x: 350
                        },
                        animate: {
                            x: 0
                        },
                        exit: {
                            x: 350
                        },
                        transition: {
                            duration: 3,
                            type: "spring",
                            stiffness: 120
                        },
                        className: "fixed right-0 bottom-0 h-full bg-blue w-[300px] rounded-l-full border-l-8 ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex justify-end p-12",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: ()=>setIsMenuToggled(!isMenuToggled),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        alt: "close-icon",
                                        src: "/assets/close-icon.svg",
                                        width: 32,
                                        height: 32
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col gap-10 ml-[33%] text-2xl text-deep-blue",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        href: "/",
                                        legacyBehavior: true,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: " hover:text-yellow transition duration-500",
                                            children: "Home"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        href: "/#services",
                                        legacyBehavior: true,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: " hover:text-yellow transition duration-500",
                                            children: "Services"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        href: "/#testimonials",
                                        legacyBehavior: true,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: " hover:text-yellow transition duration-500",
                                            children: "Testimonials"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        href: "/aboutUs",
                                        legacyBehavior: true,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: " text-yellow transition duration-500",
                                            children: "About Us"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        href: "/#contact",
                                        legacyBehavior: true,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: " hover:text-yellow transition duration-500",
                                            children: "Contact"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navbg2);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 119:
/***/ (() => {



/***/ }),

/***/ 3716:
/***/ (() => {



/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 2217:
/***/ ((module) => {

"use strict";
module.exports = require("react-anchor-link-smooth-scroll");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6197:
/***/ ((module) => {

"use strict";
module.exports = import("framer-motion");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,121,676,664,675,941], () => (__webpack_exec__(3847)));
module.exports = __webpack_exports__;

})();