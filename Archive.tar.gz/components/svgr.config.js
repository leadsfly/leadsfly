module.exports = {
  dimensions: false,
};
