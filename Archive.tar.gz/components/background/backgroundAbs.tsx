import React from "react";

function BackgroundAbs() {
  return <div>backgroundAbs</div>;
}

export default BackgroundAbs;
